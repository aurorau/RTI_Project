$(document).ready(function() {
	
});

function testJs( ){
	
    console.log();
   // var ud=$('#testId').val().trim();
    var formData= new FormData();
    //formData.push({ name: 'name', value: ud});
	//alert(ud);
 
    var ud= "ds";
/*	if (ud !='') {
		$.post('testController/saveTest', {
			name : ud
		}, function(data) {
			if (data.status == 'success') {
				
			} else {
				alert(data.status);
			}
		});
	}
	else {
		alert("Enter a value");
	}*/
 
}