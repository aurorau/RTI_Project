package com.aurora.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class BaseController {
	 @RequestMapping("/")
	 public ModelAndView hello() throws Exception {
		 //return new ModelAndView("helloworld");
		 return new ModelAndView("PTHome");
	 }
}
