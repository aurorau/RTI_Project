package com.aurora.controller;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.aurora.util.JsonResponce;

import nl.bitwalker.useragentutils.Browser;
import nl.bitwalker.useragentutils.OperatingSystem;
import nl.bitwalker.useragentutils.UserAgent;

@Controller
@RequestMapping("/homePage*")
public class HomePageController {
	 @RequestMapping(method = RequestMethod.GET)
	 public ModelAndView hello() throws Exception {
		 //return new ModelAndView("homePage");
		 return new ModelAndView("PTHome");
	 }
	 
	 @RequestMapping(method = RequestMethod.POST, value="/getHeaderString")
	 public  @ResponseBody JsonResponce getHeaderString(HttpServletRequest request, HttpServletResponse responce) throws Exception {
		 
		 JsonResponce res= new JsonResponce();
		 
/*		 String touchEnX = null;
		 String touchEny = null;
		 Long startTime = null;
		 Long endTime = null;
		 
		 String referer = request.getParameter("referer");
		 String url = request.getParameter("url");
		 String language = request.getParameter("language");
		 String userAgent = request.getParameter("userAgent");
		 String country = request.getParameter("countryName");
		 String screenHeight = request.getParameter("screenHeight");
		 String screenWidth = request.getParameter("screenWidth");
		 String region = request.getParameter("region");
		 String city = request.getParameter("city");
		 String platform = request.getParameter("platform");
		 String touchStX = request.getParameter("tsx");
		 String touchStY = request.getParameter("tsy");
		 String clickX = request.getParameter("clickX");
		 String clickY = request.getParameter("clickY");
		 if(request.getParameter("tex") != null){
			 touchEnX = request.getParameter("tex");
			 touchEny = request.getParameter("tey"); 
			 startTime = Long.parseLong(request.getParameter("startTime"));
			 endTime = Long.parseLong(request.getParameter("endTime"));
		 }*/

		 
		 //String ipAddress = request.getRemoteAddr(); 
		 
		   //is client behind something?
		   String ipAddress = request.getHeader("X-FORWARDED-FOR");  
		   if (ipAddress == null) {  
			   ipAddress = request.getRemoteAddr();  
		   }
		 
		   String userAgent = request.getParameter("userAgent");
		   System.out.println("UserAgent : "+ userAgent);
/*		   System.out.println("getAuthType :"+request.getAuthType());
		   System.out.println("getContextPath :"+request.getContextPath());
		   System.out.println("getSession_getCreationTime :"+request.getSession().getCreationTime());
		   System.out.println("getSession_getId :"+request.getSession().getId());
		   System.out.println("getSession_getLastAccessedTime :"+request.getSession().getLastAccessedTime());
		   System.out.println("getLocalAddr :"+request.getLocalAddr());
		   System.out.println("getLocalName :"+request.getLocalName());
		   System.out.println("getHeaderHOST :"+request.getHeader("Host"));
		   System.out.println("getHeaderFROM :"+request.getHeader("From"));
		   System.out.println("getHeaderReferer :"+request.getHeader("Referer"));*/
		   
		   Long creationTime = request.getSession().getCreationTime();
		   Long lastAccessTime = request.getSession().getLastAccessedTime();
		   String location = request.getParameter("location");
		   Long clickCount = Long.parseLong(request.getParameter("clickCount"));
		   Long touchCount = Long.parseLong(request.getParameter("touchCount"));
		   Long zoomCount = Long.parseLong(request.getParameter("zoomCount"));
		   Long scrollCount = Long.parseLong(request.getParameter("scrollCount"));
		   
/*		   System.out.println("Creation Time :"+getTime(creationTime));
		   System.out.println("Last Access Time :"+getTime(lastAccessTime));*/
		   
/*		   System.out.println("Touch Count :"+touchCount);
		   System.out.println("Click Count :"+clickCount);
		   System.out.println("Zoom Count :"+zoomCount);
		   System.out.println("Scroll Count :"+scrollCount);*/
		   
		  // getServerIp();
		  // getCurrentTimeBasedOnCountry(location);

/*		 System.out.println("++++++++++++");
		 System.out.println("IP address :"+ipAddress);
		 System.out.println("///////////////////");*/
		   
	        UserAgent userAgent1 = UserAgent.parseUserAgentString(request.getHeader("User-Agent"));
	        OperatingSystem agent = userAgent1.getOperatingSystem();  
	        Browser browser = userAgent1.getBrowser();
		  
	        String deviceName = agent.getDeviceType().getName();
	        
	        System.out.println("Device :"+deviceName);
	        System.out.println("OS :"+agent.getName());
	        System.out.println("Browser :"+browser.getName());
		 res.setStatus("success");
		 res.setResult(ipAddress);
		 
		 return res;
	 }
	 
	public String getTime(Long milSec){
		 
		 SimpleDateFormat formatter = new SimpleDateFormat("dd:hh:mm:ss");
		 Date date = new Date(milSec);
		 String result = formatter.format(date);
		 
		 return result;
	 }
	
	public void getServerIp() {
		  InetAddress ip;
		  try {
			ip = InetAddress.getLocalHost();
			System.out.println("Current IP address : " + ip.getHostAddress());

		  } catch (UnknownHostException e) {
			e.printStackTrace();
		  }
	}
	
	public void getCurrentTimeBasedOnCountry(String countryAndRegion) {
		Date date = new Date();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

		// Use Madrid's time zone to format the date in
		df.setTimeZone(TimeZone.getTimeZone(countryAndRegion));
		//df.setTimeZone(TimeZone.getTimeZone("Sri Lanka/Western"));
		//df.setTimeZone(TimeZone.getDefault());
		

		System.out.println("Date and time in Madrid: " + df.format(date));
        
	}
}
