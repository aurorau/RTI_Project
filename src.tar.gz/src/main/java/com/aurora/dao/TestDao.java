package com.aurora.dao;

import com.aurora.model.Person;


public interface TestDao {
	public void personSave(Person person) throws Exception;
}
