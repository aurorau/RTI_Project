package com.aurora.service;

import com.aurora.model.Person;

public interface TestService {
	public void testSave(Person person);
}
